﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ProgramCharacters.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace ProgramCharacters.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageCharacter.xaml
    /// </summary>
    public partial class PageCharacter : Page
    {
        public PageCharacter()
        {
            InitializeComponent();
            DGridCharacter.Items.SortDescriptions.Add(new SortDescription("Name", ListSortDirection.Ascending));
            CmbFiltrProv.ItemsSource = GameCharactersEntities.GetContext().PowerCharacters.ToList();
            CmbFiltrProv.SelectedValuePath = "id_power_characters";
            CmbFiltrProv.DisplayMemberPath = "Title";
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                GameCharactersEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridCharacter.ItemsSource = GameCharactersEntities.GetContext().Characters.ToList();

            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditCharacters((sender as Button).DataContext as Characters));
        }      

        private void Btn_TypeChar(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageType());
        }

        private void Btn_Weapon(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageWeapon());
        }

        private void Btn_Power(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PagePower());
        }

       

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridCharacter.ItemsSource = GameCharactersEntities.GetContext().Characters.Where(x => x.Name.ToLower().Contains(TxbSearch.Text.ToLower())).ToList();
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridCharacter.ItemsSource = GameCharactersEntities.GetContext().Characters.ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridCharacter.ItemsSource = GameCharactersEntities.GetContext().Characters.OrderBy(x => x.Name).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridCharacter.ItemsSource = GameCharactersEntities.GetContext().Characters.OrderByDescending(x => x.Name).ToList();
        }

        private void CmbFiltrProv_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = CmbFiltrProv.SelectedIndex + 1;
            DGridCharacter.ItemsSource = GameCharactersEntities.GetContext().Characters.Where(x => x.FK_Power == id).ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditCharacters(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var productForRemoving = DGridCharacter.SelectedItems.Cast<Characters>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {productForRemoving.Count()} данный продукт?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    GameCharactersEntities.GetContext().Characters.RemoveRange(productForRemoving);
                    GameCharactersEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridCharacter.ItemsSource = GameCharactersEntities.GetContext().Characters.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnExcel_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();

            // книга
            Excel.Workbook wb = app.Workbooks.Add();

            // лист
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexRows = 5;
            // ячейки
            // 1 - номер столбца 
            // 2 - номер строки
            worksheet.Cells[3][indexRows] = "Имя";
            worksheet.Cells[4][indexRows] = "Тип";
            worksheet.Cells[5][indexRows] = "Статус";
            worksheet.Cells[6][indexRows] = "Сила";
            worksheet.Cells[7][indexRows] = "Оружие";


            var printItems = DGridCharacter.Items;
            Excel.Range Bold = worksheet.Range[worksheet.Cells[3][indexRows], worksheet.Cells[7][indexRows]];

            Bold.Style.Font.Name = "Times New Roman";
            Bold.Font.Bold = true;
            Excel.Range Borders = worksheet.Range[worksheet.Cells[3][indexRows], worksheet.Cells[7][indexRows]];
            Borders.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlInsideVertical].LineStyle = Excel.XlLineStyle.xlContinuous;
            Borders.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            worksheet.Columns.AutoFit();

            Excel.Range DocumentRange = worksheet.Range[worksheet.Cells[3][2], worksheet.Cells[7][2]];
            DocumentRange.Merge();
            DocumentRange.Value = "Документ";
            DocumentRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;


            Excel.Range TitleRange = worksheet.Range[worksheet.Cells[3][3], worksheet.Cells[7][3]];
            TitleRange.Merge();
            TitleRange.Value = "Игровые персонажи";
            TitleRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            TitleRange.Style.Font.Name = "Times New Roman";

            foreach (Characters item in printItems)
            {
                worksheet.Cells[3][indexRows + 1] = indexRows - 4;
                worksheet.Cells[4][indexRows + 1] = item.Name;
                worksheet.Cells[5][indexRows + 1] = item.TypeCharacters.Title.ToString();
                worksheet.Cells[6][indexRows + 1] = item.PowerCharacters.Title.ToString();
                worksheet.Cells[7][indexRows + 1] = item.Weapon.Name.ToString();
                indexRows++;
            }
            Excel.Range Borders1 = worksheet.Range[worksheet.Cells[3][indexRows - printItems.Count], worksheet.Cells[7][indexRows]];
            Borders1.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle =
            Borders1.Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle =
            Borders1.Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle =
            Borders1.Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle =
            Borders1.Borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle =
            Borders1.Borders[Excel.XlBordersIndex.xlInsideVertical].LineStyle = Excel.XlLineStyle.xlContinuous;

            Excel.Range DirectorRange = worksheet.Range[worksheet.Cells[8][indexRows + 3], worksheet.Cells[10][indexRows + 3]];
            DirectorRange.Merge();
            DirectorRange.Value = "Подпись директора _______________________";
            DirectorRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            worksheet.Cells[8][indexRows + 7].Value = "Дата:";
            worksheet.Cells[8][indexRows + 7].Font.Bold = true;
            worksheet.Cells[8][indexRows + 7].HorizontalAlignment = Excel.XlHAlign.xlHAlignRight;

            worksheet.Cells[9][indexRows + 7].Formula = $"=TODAY()";
            worksheet.Cells[9][indexRows + 7].Font.Bold = true;

            // показать Excel
            app.Visible = true;
        }   
    }
}
