﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ProgramCharacters.Classes;

namespace ProgramCharacters.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditCharacters.xaml
    /// </summary>
    public partial class AddEditCharacters : Page
    {
        private Characters _currentCharacter = new Characters();

        public AddEditCharacters(Characters selectedCharacter)
        {
            InitializeComponent();
            if (selectedCharacter != null)
                _currentCharacter = selectedCharacter;
            //создаем контекст
            DataContext = _currentCharacter;
            CmbStat.ItemsSource = GameCharactersEntities.GetContext().StatusCharacters.ToList();
            CmbStat.SelectedValuePath = "id_status_characters";
            CmbStat.DisplayMemberPath = "Title";
            CmbPow.ItemsSource = GameCharactersEntities.GetContext().PowerCharacters.ToList();
            CmbPow.SelectedValuePath = "id_power_characters";
            CmbPow.DisplayMemberPath = "Title";
            CmbWeap.ItemsSource = GameCharactersEntities.GetContext().Weapon.ToList();
            CmbWeap.SelectedValuePath = "id_weapon";
            CmbWeap.DisplayMemberPath = "Name";
            CmbTp.ItemsSource = GameCharactersEntities.GetContext().TypeCharacters.ToList();
            CmbTp.SelectedValuePath = "id_type_characters";
            CmbTp.DisplayMemberPath = "Title";
            CmbLvl.ItemsSource = GameCharactersEntities.GetContext().LevelNPC.ToList();
            CmbLvl.SelectedValuePath = "id_level_NPC";
            CmbLvl.DisplayMemberPath = "Title";
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentCharacter.Name))
                error.AppendLine("Укажите название");
            //if (string.IsNullOrWhiteSpace(_currentProduct.Note))
            //    error.AppendLine("Укажите описание товара");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
            if (_currentCharacter.id_characters == 0)
                GameCharactersEntities.GetContext().Characters.Add(_currentCharacter); //добавить в контекст
            try
            {
                GameCharactersEntities.GetContext().SaveChanges(); // сохраняет все изменения
                MessageBox.Show("Новый продукт добавлен");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); //сообщение об ошибке
            }
        }
    }
}
