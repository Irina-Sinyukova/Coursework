﻿using ProgramCharacters.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProgramCharacters.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageTypeWeapon.xaml
    /// </summary>
    public partial class PageTypeWeapon : Page
    {
        public PageTypeWeapon()
        {
            InitializeComponent();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                GameCharactersEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridTypeWeapon.ItemsSource = GameCharactersEntities.GetContext().TypeWeapon.ToList();

            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditTypeWeapon((sender as Button).DataContext as TypeWeapon));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditTypeWeapon(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var productForRemoving = DGridTypeWeapon.SelectedItems.Cast<TypeWeapon>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {productForRemoving.Count()} данный продукт?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    GameCharactersEntities.GetContext().TypeWeapon.RemoveRange(productForRemoving);
                    GameCharactersEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridTypeWeapon.ItemsSource = GameCharactersEntities.GetContext().TypeWeapon.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
    }
}
