﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Example
{
    public static class Class1
    {
        // Возвращает значение определяющее сложность пароля пользователя.
        public static int GetPasswordStrength(string phone)
        {
            if (string.IsNullOrEmpty(phone))
            {
                return 0;
            }
            int result = 0;
            // +1 балл за длину.
            if (phone.Length == 11)
            {
                result++;
            }
            
            // +1 балл за наличие числа.
            if (Regex.Match(phone, "[0-9]").Success)
            {
                result++;
            }
           
            return result;
        }
    }
}
