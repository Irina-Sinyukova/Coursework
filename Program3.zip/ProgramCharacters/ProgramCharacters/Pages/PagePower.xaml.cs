﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ProgramCharacters.Classes;

namespace ProgramCharacters.Pages
{
    /// <summary>
    /// Логика взаимодействия для PagePower.xaml
    /// </summary>
    public partial class PagePower : Page
    {
        public PagePower()
        {
            InitializeComponent();
            DGridPower.Items.SortDescriptions.Add(new SortDescription("Title", ListSortDirection.Ascending));
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                GameCharactersEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridPower.ItemsSource = GameCharactersEntities.GetContext().PowerCharacters.ToList();

            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPower((sender as Button).DataContext as PowerCharacters));
        }
    }
}
