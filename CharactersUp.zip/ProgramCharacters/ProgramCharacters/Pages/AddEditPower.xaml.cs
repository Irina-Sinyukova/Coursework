﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ProgramCharacters.Classes;

namespace ProgramCharacters.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPower.xaml
    /// </summary>
    public partial class AddEditPower : Page
    {
        private PowerCharacters _currentPower = new PowerCharacters();
        public AddEditPower(PowerCharacters selectedPower)
        {
            InitializeComponent();
            if (selectedPower != null)
                _currentPower = selectedPower;
            //создаем контекст
            DataContext = _currentPower;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentPower.Title))
                error.AppendLine("Укажите название");
            //if (string.IsNullOrWhiteSpace(_currentProduct.Note))
            //    error.AppendLine("Укажите описание товара");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
            if (_currentPower.id_power_characters == 0)
                GameCharactersEntities.GetContext().PowerCharacters.Add(_currentPower); //добавить в контекст
            try
            {
                GameCharactersEntities.GetContext().SaveChanges(); // сохраняет все изменения
                MessageBox.Show("Новый продукт добавлен");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); //сообщение об ошибке
            }
        }
    }
}
