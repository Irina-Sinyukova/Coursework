﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ProgramCharacters.Classes;

namespace ProgramCharacters.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageCharacter.xaml
    /// </summary>
    public partial class PageCharacter : Page
    {
        public PageCharacter()
        {
            InitializeComponent();
            DGridCharacter.Items.SortDescriptions.Add(new SortDescription("Name", ListSortDirection.Ascending));
            CmbFiltrProv.ItemsSource = GameCharactersEntities.GetContext().PowerCharacters.ToList();
            CmbFiltrProv.SelectedValuePath = "id_power_characters";
            CmbFiltrProv.DisplayMemberPath = "Title";
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                GameCharactersEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridCharacter.ItemsSource = GameCharactersEntities.GetContext().Characters.ToList();

            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditCharacters((sender as Button).DataContext as Characters));
        }

        private void Btn_StatusNav(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageStatusChar());
        }

        private void Btn_TypeChar(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageType());
        }

        private void Btn_Weapon(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageWeapon());
        }

        private void Btn_Power(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PagePower());
        }

        private void Btn_LevelNPC(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageLevelNPC());
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridCharacter.ItemsSource = GameCharactersEntities.GetContext().Characters.Where(x => x.Name.ToLower().Contains(TxbSearch.Text.ToLower())).ToList();
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridCharacter.ItemsSource = GameCharactersEntities.GetContext().Characters.ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridCharacter.ItemsSource = GameCharactersEntities.GetContext().Characters.OrderBy(x => x.Name).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridCharacter.ItemsSource = GameCharactersEntities.GetContext().Characters.OrderByDescending(x => x.Name).ToList();
        }

        private void CmbFiltrProv_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = CmbFiltrProv.SelectedIndex + 1;
            DGridCharacter.ItemsSource = GameCharactersEntities.GetContext().Characters.Where(x => x.FK_Power == id).ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditCharacters(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var productForRemoving = DGridCharacter.SelectedItems.Cast<Characters>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {productForRemoving.Count()} данный продукт?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    GameCharactersEntities.GetContext().Characters.RemoveRange(productForRemoving);
                    GameCharactersEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridCharacter.ItemsSource = GameCharactersEntities.GetContext().Characters.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
    }
}
