﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ProgramCharacters.Classes;

namespace ProgramCharacters.Pages
{
    /// <summary>
    /// Логика взаимодействия для PagePower.xaml
    /// </summary>
    public partial class PagePower : Page
    {
        public PagePower()
        {
            InitializeComponent();
            DGridPower.Items.SortDescriptions.Add(new SortDescription("Title", ListSortDirection.Ascending));
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                GameCharactersEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridPower.ItemsSource = GameCharactersEntities.GetContext().PowerCharacters.ToList();

            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPower((sender as Button).DataContext as PowerCharacters));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPower(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var productForRemoving = DGridPower.SelectedItems.Cast<PowerCharacters>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {productForRemoving.Count()} данный элемент?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    GameCharactersEntities.GetContext().PowerCharacters.RemoveRange(productForRemoving);
                    GameCharactersEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridPower.ItemsSource = GameCharactersEntities.GetContext().PowerCharacters.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnTypeWeapon_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageTypeWeapon());
        }
    }
}
