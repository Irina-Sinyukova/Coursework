﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProgramCharacters.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditTypeWeapon.xaml
    /// </summary>
    public partial class AddEditTypeWeapon : Page
    {
        private TypeWeapon _currentTypeWeapon = new TypeWeapon();
        public AddEditTypeWeapon(TypeWeapon selectedTypeWeapon)
        {
            InitializeComponent();
            if (selectedTypeWeapon != null)
                _currentTypeWeapon = selectedTypeWeapon;
            //создаем контекст
            DataContext = _currentTypeWeapon;

        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentTypeWeapon.Title))
                error.AppendLine("Укажите название");
            //if (string.IsNullOrWhiteSpace(_currentProduct.Note))
            //    error.AppendLine("Укажите описание товара");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
            if (_currentTypeWeapon.id_type_weapon == 0)
                GameCharactersEntities.GetContext().TypeWeapon.Add(_currentTypeWeapon); //добавить в контекст
            try
            {
                GameCharactersEntities.GetContext().SaveChanges(); // сохраняет все изменения
                MessageBox.Show("Новый тип оружия добавлен");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); //сообщение об ошибке
            }
        }
    }
}
